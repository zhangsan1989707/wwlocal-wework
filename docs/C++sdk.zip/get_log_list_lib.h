#pragma once

#include <string>
#include <map>
#include <vector>

using namespace std;

//返回码   错误说明
//10000 参数错误，请求参数错误
//10001 网络错误，网络请求错误
//10002 数据解析失败
//10003 系统失败
//10004 密钥错误导致加密失败
//10005 fileid错误
//10006 解密失败
//10007 找不到消息加密版本的私钥，需要重新传入私钥对
//10008 解析encrypt_key出错
//10009 ip非法
//10010 数据过期
//1000000 corpid错误
//1000001 secret错误


/*
   日志id定义：
 90000031：登录
 90000032：唤醒
 90000033：访问应用
 90000034：应用推送消息
 90000035：发送消息
 90000036：单聊聊天数据
 90000037：群聊聊天数据
 90000038：创建群聊
 90000039：群加人
 90000040：群踢人
 90000041：退群
 90000042：转让群主
 90000043：解散群
 90000044: 群改名
 */

//错误吗定义
enum ErrCode
{
    ERR_INVALID_PARAM   = 10000,  //参数错误，请求参数错误
    ERR_SOCKET_ERR      = 10001,  //网络错误，网络请求错误
    ERR_PARSE_DATA_ERR  = 10002,  //数据解析失败
    ERR_SYSTEM_ERR      = 10003,  //系统失败
    ERR_ENC_KEY         = 10004,  //密钥错误导致加密失败
    ERR_FILE_ID         = 10005,  //fileid错误
    ERR_DECRYPT         = 10006,  //解密失败
    ERR_MSG_PRIVATE_KEY = 10007,  //找不到消息加密版本的私钥，需要重新传入私钥对
    ERR_PARSE_ENC_KEY   = 10008,  //解析encrypt_key出错
    ERR_INVALID_IP      = 10009,  //ip非法
    ERR_DATA_EXPIRE     = 10010,  //数据过期
    ERR_COPR_ID         = 1000000,  //coprid错误
    ERR_SECRECT         = 1000001,  //secrect错误
};

struct LogInfo
{
public:
    LogInfo():feature_id(0), log_time(0), idc(""), log_data(""),enc_ver(0),enc_key(""),enc_data("") {};
    ~LogInfo(){};
public:
    unsigned int feature_id;
    unsigned int log_time;
    string idc;
    string log_data;        //json字符串
    unsigned int enc_ver;
    string enc_key;
    string enc_data;
};

struct LogMediaData
{
public:
    LogMediaData():is_finished(false),enc_key(""),enc_ver(0),enc_data(""){};
    ~LogMediaData(){};

public:
    std::string data;
    bool is_finished;
    string enc_key;
    unsigned int enc_ver;  
    string enc_data;
};

class WeWorkLocalSdk
{
public:

    /**
     * 构造函数
     *
     * * @param [in]  url     服务器url，例如：https://saastest2.weixin.com:80
     */
    WeWorkLocalSdk(const std::string &url);
    ~WeWorkLocalSdk();

    /**
     * 初始化函数
     *
     * @param [in]  corpid      调用企业的企业id，例如：wwd08c8exxxx5ab44d，可以在企业微信管理端--我的企业--企业信息查看
     * @param [in]  secret      聊天内容存档的Secret，可以在企业微信管理端--管理工具--日志及数据导出查看
     *
     *
     * @return 返回是否初始化成功
     *      0   - 成功
     *      其他 - 失败
     */
    int Init(const std::string &corpid, const std::string &secrect);

    /**
     * 设置日志解密私钥（管理端“日志及数据导出”模块公钥对应的私钥）
     *
     * @param [in]  rsa_pri_key_data     私钥字符串值(SetRsaPrivateKey和SetRsaPrivateKeyPath只需要选一个设置即可)
     *
     * @return 返回是否初始化成功
     *      0   - 成功
     *      其他 - 失败
     */
    int SetRsaPrivateKey(const string &rsa_pri_key_data);

    /**
     * 设置日志解密私钥（管理端“日志及数据导出”模块公钥对应的私钥）
     *
     * @param [in]  rsa_pri_key_file     私钥文件路径，要保证该文件有读取权限(SetRsaPrivateKey和SetRsaPrivateKeyPath只需要选一个设置即可)
     *
     * @return 返回是否初始化成功
     *      0   - 成功
     *      其他 - 失败
     */
    int SetRsaPrivateKeyPath(const string &rsa_pri_key_file);

    /**
     * 获取日志
     *
     * @param [in]  feature_id      业务ID，（详见：日志id定义）
     * @param [in]  start_time      需要获取日志的开始时间
     * @param [in]  end_time        需要获取日志的结束时间，且start_time与end_time需在同一天。
     * @param [in]  start           分页ID，初始值是0，以后每次累加上次请求返回的log_list的长度
     * @param [in]  limit           每页获取个数
     * @param [out]  log_list       日志列表，当接口返回的log_list的长度<limit时表示拉取结束
     *
     * @return 返回是否初始化成功
     *      0   - 成功
     *      其他 - 失败
     */
    int GetLogList(unsigned int feature_id,
            unsigned long long start_time,
            unsigned long long end_time,
            unsigned int start,
            unsigned int limit,
            std::vector<LogInfo> &log_list);

    /**
       * 获取日志中的媒体文件
       *
       * @param [in]  file_id         聊天记录中记录的文件ID
       * @param [in]  start_index     要获取的文件内容在全部内容中的起始序号，初始值是0
       * @param [in]  block_size      要获取的文件内容大小（字节），为0时获取到文件末尾
       * @param [out]  log_media_data 获取到的文件内容
       *
       * @return 返回是否获取成功
       *      0   - 成功
       *      其他 - 失败
       */
       int GetLogMediaData(const string &file_id,
               unsigned long long start_index,
               unsigned long long block_size,
               LogMediaData &log_media_data);

       /**
        * 设置超时时间
        */
       void SetTimeOut(unsigned int iSecond);

     /**
       * 解密日志内容和文件信息
       *
       * @param [in]  enc_data             需要解密的数据
       * @param [in]  enc_key              解密key
       * @param [out] dec_data             解密的数据内容
       *
       * @return 返回是否获取成功
       *      0   - 成功
       *      其他 - 失败
       */
    
       int DecryptData(const string enc_data, string enc_key, string &dec_data);

private:

    //获取token并设置有效期，获取日志前判断有效期
    int RefreshToken(const std::string &proxy,const std::string &passwd);

private:
    string corpid_;
    string secrect_;
    string url_;
    string rsa_pri_key_file_;
    string rsa_pri_key_;
    string token_;
    unsigned long long expire_time_;  //token_过期时间
    unsigned int timeout_; //curl 超时时间
};

